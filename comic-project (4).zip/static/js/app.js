/* ComicCraft front-end enhancements (UX only — all business logic is server-side). */
(function () {
  "use strict";

  /* ---------------------- comic creation form ---------------------- */
  var form = document.getElementById("comic-form");
  if (form) {
    var button = document.getElementById("generate-btn");
    var loading = document.getElementById("loading");
    var loadingTitle = document.getElementById("loading-title");
    var loadingSub = document.getElementById("loading-sub");
    var requiredFields = Array.prototype.slice.call(
      form.querySelectorAll("input[required], textarea[required]")
    );

    // Gentle client-side validation assistance (server still re-validates).
    requiredFields.forEach(function (field) {
      field.addEventListener("input", function () {
        if (field.classList.contains("invalid") && field.value.trim()) {
          field.classList.remove("invalid");
        }
      });
    });

    form.addEventListener("submit", function (event) {
      var invalid = requiredFields.filter(function (field) {
        var empty = !field.value.trim();
        field.classList.toggle("invalid", empty);
        return empty;
      });

      if (invalid.length > 0) {
        event.preventDefault();
        invalid[0].focus();
        return;
      }

      // Loading state + duplicate-submission guard.
      if (button.disabled) {
        event.preventDefault();
        return;
      }
      button.disabled = true;
      button.setAttribute("aria-busy", "true");
      button.querySelector(".btn-label").textContent = "Generating…";

      if (loading) {
        loading.hidden = false;
        var started = Date.now();
        // Honest, stage-based messaging — no fake progress percentages.
        var stages = [
          { after: 0,     title: "Planning your 5-panel story…", sub: "Shaping the outline and writing dialogue." },
          { after: 15000, title: "Writing narration & dialogue…", sub: "Making sure the story stays consistent." },
          { after: 40000, title: "Illustrating your panels…",     sub: "Drawing panels 1–5 — this is the slow part." },
          { after: 90000, title: "Almost there…",                 sub: "Putting the finishing touches on your comic." }
        ];
        var timer = setInterval(function () {
          var elapsed = Date.now() - started;
          for (var i = stages.length - 1; i >= 0; i--) {
            if (elapsed >= stages[i].after) {
              if (loadingTitle) loadingTitle.textContent = stages[i].title;
              if (loadingSub) loadingSub.textContent = stages[i].sub;
              break;
            }
          }
        }, 1000);

        // Safety: re-enable the button if the user navigates back (bfcache).
        window.addEventListener("pageshow", function () {
          clearInterval(timer);
          button.disabled = false;
          button.removeAttribute("aria-busy");
          button.querySelector(".btn-label").textContent = "⚡ Generate My Comic";
          if (loading) loading.hidden = true;
        });
      }
    });
  }

  /* ------------------------- image test form ------------------------ */
  var testForm = document.getElementById("test-image-form");
  if (testForm) {
    var testLoading = document.getElementById("loading");
    var resultBox = document.getElementById("test-result");
    var resultImg = document.getElementById("test-image");
    var resultMsg = document.getElementById("test-message");

    testForm.addEventListener("submit", function (event) {
      event.preventDefault();
      var promptEl = document.getElementById("prompt");
      var prompt = promptEl.value.trim();
      if (prompt.length < 3) {
        promptEl.classList.add("invalid");
        promptEl.focus();
        return;
      }

      var submitBtn = testForm.querySelector("button[type=submit]");
      submitBtn.disabled = true;
      if (testLoading) testLoading.hidden = false;
      if (resultBox) resultBox.hidden = true;

      fetch("/test-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: prompt })
      })
        .then(function (response) {
          return response.json().then(function (data) {
            return { ok: response.ok, data: data };
          });
        })
        .then(function (result) {
          if (testLoading) testLoading.hidden = true;
          submitBtn.disabled = false;
          if (resultBox) resultBox.hidden = false;
          if (resultMsg) {
            resultMsg.textContent = result.ok
              ? (result.data.message || "Image generated.")
              : (result.data.detail || "Image generation failed.");
          }
          if (result.ok && resultImg && result.data.image_url) {
            resultImg.src = result.data.image_url;
          } else if (resultImg) {
            resultImg.removeAttribute("src");
          }
        })
        .catch(function () {
          if (testLoading) testLoading.hidden = true;
          submitBtn.disabled = false;
          if (resultBox) resultBox.hidden = false;
          if (resultMsg) resultMsg.textContent = "Could not reach the server. Is it still running?";
          if (resultImg) resultImg.removeAttribute("src");
        });
    });
  }
})();
