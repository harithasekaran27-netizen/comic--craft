# ComicCraft — Architecture

## Overview

ComicCraft turns five user inputs into a finished, downloadable 5-panel comic:

```
USER
 ↓
WEB UI (Jinja2 + vanilla JS)
 ↓
FASTAPI (routes.py)
 ↓
INPUT VALIDATION (schemas.py + utils/validators.py)
 ↓
COMIC OUTLINE GENERATION   (services/gemini_flash.py   → Gemini 3.8 Flash, structured JSON)
 ↓
STORY + DIALOGUE GENERATION (services/gemini_pro.py    → Gemini 3.8 Flash, structured JSON)
 ↓
IMAGE PROMPT GENERATION    (services/image_prompts.py  → deterministic composition)
 ↓
AI IMAGE GENERATION        (services/image_generator.py → provider-based, default Gemini image model)
 ↓
COMIC LAYOUT               (services/layout_builder.py → structured panel list)
 ↓
COMIC PREVIEW              (templates/comic_preview.html)
 ↓
PDF EXPORT                 (services/exporters.py → ReportLab)
 ↓
DOWNLOAD / SUCCESS PAGE    (templates/export_success.html)
```

## Backend architecture

- `app/main.py` — FastAPI app factory, static mount, exception handlers, startup checks.
- `app/routes.py` — All HTTP routes (HTML + JSON), sync handlers so long AI calls run in the
  threadpool and never block the event loop.
- `app/schemas.py` — Pydantic v2 request/response/domain models (ComicRequest, Panel, Comic,
  GenerationResponse, ExportResponse, AI outline/story schemas).
- `app/config.py` — `pydantic-settings` Settings loaded from `.env`; single source of truth for
  model names, provider choice, mock mode; never exposes secrets to templates.
- `app/services/` — one module per pipeline stage (see AI pipeline below).
- `app/utils/` — `validators.py` (text/filename sanitizing) and `helpers.py` (ids, slugs, files).
- `app/errors.py` — `ComicServiceError` hierarchy with safe user-facing messages.

## Frontend architecture

- Server-rendered Jinja2 templates (`templates/`) with a shared `base.html`.
- `static/css/style.css` — responsive, comic-inspired design (CSS variables, mobile breakpoints).
- `static/js/app.js` — progressive enhancement only: loading state, double-submit guard,
  client-side validation hints. All business logic stays server-side.
- Jinja2 auto-escaping is ON; AI/user text is always escaped.

## AI pipeline (model responsibilities)

| Role | Module | Default model | Output |
|---|---|---|---|
| Fast structured outline (5 panels) | `services/gemini_flash.py` | `gemini-3.8-flash` | JSON validated into `ComicOutline` |
| Detailed narration + dialogue | `services/gemini_pro.py` | `gemini-3.8-flash` | JSON validated into `ComicStory` |
| Image prompt composition | `services/image_prompts.py` | deterministic (no LLM) | One prompt per panel |
| Illustration | `services/image_generator.py` | `gemini-3.1-flash-image` | PNG saved to `static/panels/` |

Model compatibility notes (Phase 33, updated for Gemini 3.x): the original spec named "Gemini Flash", "Gemini Pro" and
local Stable Diffusion. Text stages now use Gemini 3.8 Flash via the
current `google-genai` SDK with native structured (JSON-schema) output. Local Stable Diffusion
via Diffusers/PyTorch was replaced by a **pluggable image-provider layer** with three
implementations — `gemini` (Gemini image model, no GPU needed), `hf` (Hugging Face Inference
API text-to-image, e.g. FLUX.1-schnell / SDXL) and `placeholder` (clearly-labeled local
Pillow placeholder used by tests and mock mode). A local Diffusers provider can be added
later without touching any other module; the functional requirement
(USER STORY → IMAGE PROMPT → AI IMAGE → SAVED PANEL IMAGE) is preserved.

## Data flow

1. `POST /generate` (form) or `POST /generate-comic/json` (JSON) → `ComicRequest` validated.
2. `comic_pipeline.generate_comic(request)` orchestrates:
   outline → story → image prompts → per-panel images (failures mark the panel, never abort
   the whole comic) → layout → `Comic` object.
3. The `Comic` is kept in an in-memory store AND persisted to `data/comics/<id>.json`,
   so PDF export still works after a dev-server reload or restart.
4. `POST /export` (comic_id) → `save_pdf()` writes `static/exports/comic_<id>_<ts>.pdf`
   → redirect to `/export-success?pdf=...`.
5. `static/panels/` and `static/exports/` are served by FastAPI `StaticFiles`.

## Error-handling strategy

- Every AI/file failure raises a `ComicServiceError` subclass carrying a safe user message.
- Route + global exception handlers render a friendly error page for HTML requests and a
  structured JSON error for API requests — users never get a blank page or a stack trace.
- Full tracebacks go to the developer log only; secrets are never logged or rendered.

## Testing strategy

- `pytest` with mocked AI services (`MOCK_AI=true` + `IMAGE_PROVIDER=placeholder`), so the
  whole suite runs offline with zero paid API calls.
- Suite: schema validation, all routes, layout builder (order/mapping/missing image), PDF
  export (file created, all panels present, corrupt image does not crash), verified with `pypdf`.

## Deployment strategy

Local deployment: `uvicorn app.main:app --reload` (or `python run.py`). Configuration entirely
via `.env`. Production notes (reverse proxy, workers, persistent disk for static/) in README.
