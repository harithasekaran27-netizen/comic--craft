# ComicCraft — AI Comic Story Creator

ComicCraft turns five simple inputs — **story prompt, main character, setting, tone and art
style** — into a complete 5-panel comic: it writes a structured outline, writes the narration
and dialogue, illustrates every panel with AI, shows a comic preview page, and exports the
whole comic as a professionally laid-out PDF.

```
INPUT → VALIDATION → OUTLINE (Gemini Flash) → STORY & DIALOGUE (Gemini Pro)
      → IMAGE PROMPTS → AI ILLUSTRATIONS → LAYOUT → PREVIEW → PDF → DOWNLOAD
```

## Features

- AI-generated comic stories with a coherent 5-panel narrative arc
  (introduction → development → conflict → climax → resolution, adapted when the story needs it)
- Panel-by-panel generation: title, scene description, caption, narration, dialogue, image
- Gemini-powered outline (fast model) and story/dialogue (pro model) with **structured JSON
  output** validated through Pydantic schemas — no fragile prose parsing
- AI-generated illustrations with a character-consistency sheet and per-panel camera/lighting
  composition; pluggable image backends (Gemini image model / Hugging Face / placeholder)
- Comic preview page with responsive card layout
- **PDF comic export** (ReportLab) with cover metadata, one page per panel, preserved aspect
  ratios, Unicode-capable fonts, and graceful handling of missing images
- REST API with automatic Swagger/ReDoc documentation
- Developer image-testing endpoint (`/test-image`)
- Environment-variable based configuration — API keys never touch source code
- Robust error handling: failed outline/story/layout stop gracefully with a friendly page;
  a failed panel image marks only that panel and the rest of the comic continues
- Structured logging of every pipeline stage with timings (never logs secrets)
- Offline **demo/mock mode** (automatic when no API key is set) that produces clearly-labeled
  placeholder content — the whole app, UI and PDF flow work without any paid API calls
- 47 automated tests (schemas, routes, layout, PDF) run fully offline with mocked AI

## Architecture

```
ComicCraft/
├── app/
│   ├── main.py                 # FastAPI app factory, static mount, error handlers, lifespan
│   ├── routes.py               # All HTTP routes (HTML pages + JSON API + export + test-image)
│   ├── schemas.py              # Pydantic request/AI/domain/response models
│   ├── config.py               # pydantic-settings configuration (single source of truth)
│   ├── errors.py               # ComicServiceError hierarchy with safe user messages
│   ├── services/
│   │   ├── gemini_client.py    # Shared Gemini SDK client + retry + structured-output helper
│   │   ├── gemini_flash.py     # Stage 1: generate_outline()  → 5-panel structured outline
│   │   ├── gemini_pro.py       # Stage 2: generate_story()   → narration + dialogue
│   │   ├── image_prompts.py    # Stage 3: deterministic image-prompt composition
│   │   ├── image_generator.py  # Stage 4: generate_image()   → provider-based illustrations
│   │   ├── layout_builder.py   # Stage 5: build_comic_layout()
│   │   ├── exporters.py        # Stage 6: save_pdf()         → ReportLab PDF
│   │   ├── comic_pipeline.py   # Orchestrates all stages with the failure policy
│   │   ├── comic_store.py      # In-memory + JSON persistence of generated comics
│   │   └── mock_ai.py          # Clearly-labeled mock generators (offline/demo mode)
│   └── utils/
│       ├── validators.py       # Text cleaning, safe-id/filename validation
│       └── helpers.py          # IDs, slugs, timestamps, filename sanitizing
├── templates/                  # Jinja2: base, index, comic_preview, export_success, error, test_image
├── static/
│   ├── css/style.css           # Comic-inspired responsive design system
│   ├── js/app.js               # UX only: loading state, validation hints, submit guard
│   ├── panels/                 # Generated panel images (served at /static/panels/)
│   └── exports/                # Generated PDF files  (served at /static/exports/)
├── data/comics/                # Persisted comic JSON (survives server restarts)
├── tests/                      # pytest suite: schemas, routes, layout, export
├── docs/ARCHITECTURE.md        # Detailed architecture document
├── .env.example                # Configuration template (copy to .env)
├── requirements.txt            # Runtime dependencies
├── requirements-dev.txt        # + pytest, pypdf
└── run.py                      # Convenience launcher
```

### Tech stack

| Layer | Technology |
|---|---|
| Backend | Python 3.10+, FastAPI, Uvicorn |
| Frontend | Jinja2 templates, vanilla CSS + JS (no build step) |
| Validation | Pydantic v2, pydantic-settings |
| Story AI | Google Gemini via `google-genai` (structured JSON output) |
| Image AI | Gemini image model (default) or Hugging Face Inference API — pluggable |
| Imaging | Pillow (validation + placeholders) |
| PDF | ReportLab |
| Tests | pytest + FastAPI TestClient + pypdf |

### Model compatibility notes

The original specification named *Gemini Flash*, *Gemini Pro* and local *Stable Diffusion*.
Current equivalents are used while preserving every functional role:

- **Gemini 2.5 Flash** for fast structured outline generation
- **Gemini 2.5 Pro** for detailed story/dialogue generation
- The local Diffusers/PyTorch image stack was replaced by a **pluggable image-provider layer**
  (`gemini` | `hf` | `placeholder`) so no GPU is required and the backend can be swapped via
  configuration without touching other modules. Model names are centralized in `.env`
  (`GEMINI_OUTLINE_MODEL`, `GEMINI_STORY_MODEL`, `GEMINI_IMAGE_MODEL`, `HF_IMAGE_MODEL`).

## Requirements

- **Python 3.10 or newer** (developed and tested on 3.14)
- A **Gemini API key** from [Google AI Studio](https://aistudio.google.com/apikey) for real
  generation (optional — without it the app runs in clearly-labeled demo mode)
- A **Hugging Face token** only if you select `IMAGE_PROVIDER=hf`
- No GPU required with the default Gemini image provider; a local Diffusers provider would
  need its own hardware

## Installation

**Windows (PowerShell / CMD):**

```bat
cd D:\comic
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-dev.txt
copy .env.example .env
:: edit .env and set GEMINI_API_KEY=your-real-key
```

**macOS / Linux:**

```bash
cd /path/to/comic
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env
# edit .env and set GEMINI_API_KEY=your-real-key
```

## Environment variables

Copy `.env.example` to `.env` and fill in your values. **Never commit the real `.env`** and
never hard-code keys in source code.

| Variable | Purpose | Default |
|---|---|---|
| `GEMINI_API_KEY` | Gemini story/outline/image generation | *(empty → demo mode)* |
| `HF_API_KEY` | Hugging Face image API (only for `IMAGE_PROVIDER=hf`) | *(empty)* |
| `MOCK_AI` | `true` forces offline mock content even with a key | `false` |
| `IMAGE_PROVIDER` | `gemini` \| `hf` \| `placeholder` | `gemini` |
| `GEMINI_OUTLINE_MODEL` | Fast outline model | `gemini-3.8-flash` |
| `GEMINI_STORY_MODEL` | Story/dialogue model | `gemini-3.8-flash` |
| `GEMINI_IMAGE_MODEL` | Illustration model | `gemini-3.1-flash-image` |
| `HF_IMAGE_MODEL` | HF text-to-image model | `black-forest-labs/FLUX.1-schnell` |
| `PANEL_COUNT` | Panels per comic (1–12) | `5` |

## Running the application

```bash
uvicorn app.main:app --reload
```

or equivalently:

```bash
python run.py
```

Then open:

| URL | Description |
|---|---|
| <http://127.0.0.1:8000/> | Homepage — the comic creator form |
| <http://127.0.0.1:8000/docs> | Swagger UI (interactive API docs) |
| <http://127.0.0.1:8000/redoc> | ReDoc API documentation |
| <http://127.0.0.1:8000/test-image> | Developer image-generation test page |

### API endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/` | Creator home page |
| POST | `/generate` | HTML form flow → renders the comic preview |
| POST | `/generate-comic/json` | JSON API → structured comic (panels, warnings, export info) |
| GET | `/comic/{comic_id}` | Re-open a generated comic's preview (permalink) |
| POST | `/export` | Export a comic to PDF → redirect to success page |
| GET | `/export-success` | Export success page with download link |
| GET/POST | `/test-image` | Developer image-generation test |
| GET | `/health` | Health/config probe |

Example (`/generate-comic/json`):

```json
{
  "story_prompt": "A brave fox exploring an enchanted forest.",
  "character_name": "Leo",
  "setting": "Enchanted Forest",
  "tone": "Adventure",
  "art_style": "Comic Book"
}
```

## Testing

```bash
pytest tests/ -v
```

The suite runs fully offline (mocked AI, placeholder images) — no API keys or paid calls
needed. It covers schema validation, every route, the layout builder (count/order/mapping/
missing images) and the PDF exporter (verified with `pypdf`).

## Troubleshooting

| Problem | Fix |
|---|---|
| *"Demo mode"* banner, mock stories/images | `GEMINI_API_KEY` is missing or empty in `.env`; add your key and restart |
| `MOCK_AI=true` startup error | Mock mode was forced explicitly — set a key or remove `MOCK_AI` |
| `ModuleNotFoundError` after install | Reinstall deps in the **activated** venv: `pip install -r requirements-dev.txt` |
| Image generation fails | Check the provider: `gemini` needs `GEMINI_API_KEY`; `hf` needs `HF_API_KEY`; or set `IMAGE_PROVIDER=placeholder` |
| Model-loading / model-not-found errors | Model names move over time — override `GEMINI_*_MODEL` / `HF_IMAGE_MODEL` in `.env` |
| CUDA/GPU errors | Only relevant for custom local providers; the default Gemini provider is cloud-based and needs no GPU |
| PDF export fails | Check `static/exports/` is writable and has disk space; the error page names the stage |
| Port already in use | `uvicorn app.main:app --reload --port 8001` (or stop the other process) |
| Story generation times out | The Gemini call retries twice; if your network is slow, raise `request_timeout_seconds` in `app/config.py` |

## Security notes

- Secrets live only in `.env` (git-ignored); they are never rendered to templates, returned
  by the API, or logged
- All user input is validated and length-limited through Pydantic; AI output is treated as
  untrusted and always escaped by Jinja2 auto-escaping
- Generated filenames are server-created slugs; comic ids and export filenames are validated
  against strict allow-list patterns before any filesystem access (path traversal is rejected)
- Errors show safe user messages; stack traces go to the server log only
