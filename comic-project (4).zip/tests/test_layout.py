"""Layout builder tests (Phase 22 — layout tests)."""

from __future__ import annotations

import pytest

from app.errors import LayoutError
from app.schemas import ComicOutline, ComicRequest, ComicStory, OutlinePanel, StoryPanel
from app.services import gemini_flash, gemini_pro, layout_builder
from app.services.image_generator import generate_image

VALID = dict(
    story_prompt="A brave fox exploring an enchanted forest.",
    character_name="Leo",
    setting="Enchanted Forest",
    tone="Adventure",
    art_style="Comic Book",
)


def _request() -> ComicRequest:
    return ComicRequest(**VALID)


def _outline_and_story():
    request = _request()
    outline = gemini_flash.generate_outline(request)  # deterministic mock
    story = gemini_pro.generate_story(request, outline)
    return request, outline, story


def test_layout_correct_panel_count_and_ordering():
    request, outline, story = _outline_and_story()
    panels = layout_builder.build_comic_layout(request, outline, story, image_paths={})
    assert [p.panel_number for p in panels] == [1, 2, 3, 4, 5]


def test_layout_maps_each_image_to_correct_panel():
    request, outline, story = _outline_and_story()
    paths = {
        p.panel_number: generate_image(f"test panel {p.panel_number}", comic_id="layouttest", panel_number=p.panel_number)
        for p in story.panels[:2]
    }
    panels = layout_builder.build_comic_layout(request, outline, story, image_paths=paths)
    for panel in panels:
        if panel.panel_number in paths:
            assert panel.image_path == paths[panel.panel_number]
            assert f"_{panel.panel_number}_" in panel.image_path
        else:
            assert panel.image_path is None


def test_layout_missing_image_marks_panel_not_crash():
    request, outline, story = _outline_and_story()
    panels = layout_builder.build_comic_layout(
        request, outline, story,
        image_paths={},
        image_errors={1: "provider timeout"},
    )
    assert panels[0].image_path is None
    assert panels[0].image_error == "provider timeout"
    assert all(p.image_path is None for p in panels)


def test_layout_nonexistent_image_file_becomes_missing():
    request, outline, story = _outline_and_story()
    panels = layout_builder.build_comic_layout(
        request, outline, story,
        image_paths={1: "/static/panels/nope_does_not_exist.png"},
    )
    assert panels[0].image_path is None


def test_layout_rejects_story_outline_mismatch():
    request, outline, story = _outline_and_story()
    broken = ComicStory(
        comic_title=story.comic_title,
        panels=story.panels[:3],  # fewer panels than outline
    )
    with pytest.raises(LayoutError):
        layout_builder.build_comic_layout(request, outline, broken, image_paths={})


def test_outline_mock_has_five_beats_and_consistent_numbering():
    outline = gemini_flash.generate_outline(_request())
    numbers = [p.panel_number for p in outline.panels]
    assert numbers == [1, 2, 3, 4, 5]
    assert outline.character_description  # needed for visual consistency
    assert OutlinePanel in [type(p) for p in outline.panels]


def test_story_mock_preserves_outline_panels():
    request = _request()
    outline = gemini_flash.generate_outline(request)
    story = gemini_pro.generate_story(request, outline)
    assert [p.panel_number for p in story.panels] == [p.panel_number for p in outline.panels]
