"""Route tests (Phase 22 — route tests). All AI/image calls are mocked."""

from __future__ import annotations


class TestHomePage:
    def test_get_home_returns_form(self, client):
        response = client.get("/")
        assert response.status_code == 200
        assert "ComicCraft" in response.text
        for field in ("story_prompt", "character_name", "setting", "tone", "art_style"):
            assert f'name="{field}"' in response.text


class TestGenerateForm:
    def test_generate_renders_preview_with_five_panels(self, client, sample_request_payload):
        response = client.post("/generate", data=sample_request_payload)
        assert response.status_code == 200
        assert "Your comic is ready" in response.text
        assert response.text.count('class="panel-card"') == 5
        assert "Download Your Comic as PDF" in response.text
        assert "/static/panels/" in response.text  # placeholder images served

    def test_generate_missing_fields_shows_errors(self, client):
        response = client.post("/generate", data={"story_prompt": "A story about a fox"})
        assert response.status_code == 422
        assert "Please fix" in response.text

    def test_generate_empty_prompt_rejected(self, client, sample_request_payload):
        sample_request_payload["story_prompt"] = "  "
        response = client.post("/generate", data=sample_request_payload)
        assert response.status_code == 422


class TestJsonApi:
    def test_generate_comic_json_returns_structured_comic(self, client, sample_request_payload):
        response = client.post("/generate-comic/json", json=sample_request_payload)
        assert response.status_code == 200
        body = response.json()
        assert body["comic_id"]
        assert body["mock_mode"] is True
        assert len(body["panels"]) == 5
        panel = body["panels"][0]
        for key in ("panel_number", "title", "scene_description", "narration",
                    "caption", "dialogue", "image_prompt", "image_path"):
            assert key in panel
        assert panel["image_path"].startswith("/static/panels/")
        assert body["export_url"] == "/export"

    def test_generate_comic_json_invalid_payload(self, client):
        response = client.post("/generate-comic/json", json={"story_prompt": "x"})
        assert response.status_code == 422
        assert "detail" in response.json()


class TestExportFlow:
    def test_export_creates_pdf_and_redirects(self, client, sample_request_payload):
        generated = client.post("/generate-comic/json", json=sample_request_payload).json()
        comic_id = generated["comic_id"]

        response = client.post("/export", data={"comic_id": comic_id}, follow_redirects=False)
        assert response.status_code == 303
        location = response.headers["location"]
        assert location.startswith("/export-success?pdf=")

        success = client.get(location)
        assert success.status_code == 200
        assert "exported" in success.text
        assert "/static/exports/" in success.text

    def test_export_unknown_comic_404(self, client):
        response = client.post("/export", data={"comic_id": "nonexistent1"})
        assert response.status_code == 404

    def test_export_unsafe_comic_id_404(self, client):
        response = client.post("/export", data={"comic_id": "../../etc"})
        assert response.status_code == 404

    def test_export_success_bad_pdf_404(self, client):
        response = client.get("/export-success?pdf=../secret.pdf")
        assert response.status_code == 404


class TestPermalink:
    def test_comic_preview_by_id(self, client, sample_request_payload):
        generated = client.post("/generate-comic/json", json=sample_request_payload).json()
        response = client.get(f"/comic/{generated['comic_id']}")
        assert response.status_code == 200
        assert generated["title"] in response.text

    def test_comic_unknown_id_404(self, client):
        assert client.get("/comic/aaaaaaaaaa").status_code == 404


class TestImageTestRoute:
    def test_get_test_image_page(self, client):
        response = client.get("/test-image")
        assert response.status_code == 200
        assert "Image generation test" in response.text

    def test_post_test_image_json(self, client):
        response = client.post(
            "/test-image",
            json={"prompt": "A brave fox standing in an enchanted forest, comic book illustration."},
        )
        assert response.status_code == 200
        body = response.json()
        assert body["success"] is True
        assert body["provider"] == "placeholder"  # mock mode: honest provider label
        assert body["image_url"].startswith("/static/panels/")

    def test_post_test_image_too_short_prompt(self, client):
        response = client.post("/test-image", json={"prompt": "hi"})
        assert response.status_code == 422

    def test_generated_image_is_reachable(self, client):
        body = client.post("/test-image", json={"prompt": "cosmic whale, pixel art"}).json()
        image = client.get(body["image_url"])
        assert image.status_code == 200
        assert image.headers["content-type"].startswith("image/")


class TestHealthAndDocs:
    def test_health(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"

    def test_swagger_docs_available(self, client):
        assert client.get("/docs").status_code == 200

    def test_redoc_available(self, client):
        assert client.get("/redoc").status_code == 200

    def test_openapi_schema_describes_api(self, client):
        schema = client.get("/openapi.json").json()
        for path in ("/generate-comic/json", "/test-image"):
            assert path in schema["paths"]
