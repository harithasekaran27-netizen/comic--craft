"""PDF export tests (Phase 22 — PDF tests), verified with pypdf."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from pypdf import PdfReader

from app.config import BASE_DIR, EXPORTS_DIR
from app.schemas import Comic, ComicRequest, DialogueLine, Panel
from app.services.exporters import save_pdf

VALID = dict(
    story_prompt="A brave fox exploring an enchanted forest.",
    character_name="Leo",
    setting="Enchanted Forest",
    tone="Adventure",
    art_style="Comic Book",
)


def _comic(panels: list[Panel], title: str = "Leo and the Enchanted Forest") -> Comic:
    return Comic(
        id="exporttest01",
        title=title,
        character_description="a fox with amber fur",
        created_at=datetime.now(timezone.utc),
        request=ComicRequest(**VALID),
        panels=panels,
        mock_mode=True,
    )


def _panel(number: int, image_path: str | None = None) -> Panel:
    return Panel(
        panel_number=number,
        title=f"Test Panel {number}",
        scene_description=f"Scene description {number} — the forest deepens.",
        narration=f"Narration {number}: Leo moves carefully between the trees.",
        caption="Deep in the forest — dawn",
        dialogue=[DialogueLine(speaker="Leo", line=f"Dialogue line {number}.")],
        image_prompt=f"prompt {number}",
        image_path=image_path,
    )


def _pdf_text(comic: Comic) -> tuple[str, Path, int]:
    url = save_pdf(comic)
    path = BASE_DIR / "static" / url.removeprefix("/static/")
    reader = PdfReader(str(path))
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    return text, path, len(reader.pages)


def test_pdf_created_with_all_panels():
    comic = _comic([_panel(i) for i in range(1, 6)])
    text, path, pages = _pdf_text(comic)
    assert path.exists()
    assert path.parent == EXPORTS_DIR
    assert path.suffix == ".pdf"
    assert pages >= 5
    assert comic.title in text
    for i in range(1, 6):
        assert f"Test Panel {i}" in text
        assert f"Narration {i}" in text
    assert "Leo: Dialogue line 3." in text
    assert "Deep in the forest" in text


def test_pdf_long_text_wrapped_not_truncated():
    panel = _panel(1)
    panel.narration = ("Leo walked and walked. " * 120).strip()
    text, path, pages = _pdf_text(_comic([panel, _panel(2)]))
    assert pages >= 2
    assert text.count("Leo walked and walked") > 50  # text flowed, not cut


def test_pdf_missing_image_does_not_crash():
    comic = _comic([_panel(1, image_path=None), _panel(2, image_path=None)])
    text, path, pages = _pdf_text(comic)
    assert path.exists()
    assert "Image unavailable" in text


def test_pdf_corrupt_image_file_does_not_crash():
    corrupt = EXPORTS_DIR.parent / "panels" / "testexport_corrupt.png"
    corrupt.write_bytes(b"this is not a png at all")
    try:
        comic = _comic([_panel(1, image_path="/static/panels/testexport_corrupt.png"), _panel(2)])
        text, path, pages = _pdf_text(comic)
        assert path.exists()
        assert "Image unavailable" in text  # graceful placeholder box
    finally:
        corrupt.unlink(missing_ok=True)


def test_pdf_unique_timestamped_filenames():
    comic = _comic([_panel(1)], title="Unique Name A")
    url_a = save_pdf(comic)
    url_b = save_pdf(comic)
    assert url_a != url_b
    assert comic.id in url_a
    assert "unique-name-a" in url_a.lower()
