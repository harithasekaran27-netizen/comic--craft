"""Schema + validator tests (Phase 22 — schema tests)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from app.schemas import ComicOutline, ComicRequest, ComicStory, Panel
from app.utils.helpers import safe_slug, sanitize_filename
from app.utils.validators import clean_text, valid_comic_id, valid_filename

VALID = {
    "story_prompt": "A brave fox exploring an enchanted forest.",
    "character_name": "Leo",
    "setting": "Enchanted Forest",
    "tone": "Adventure",
    "art_style": "Comic Book",
}


class TestComicRequest:
    def test_valid_request(self):
        request = ComicRequest(**VALID)
        assert request.character_name == "Leo"

    def test_missing_fields_rejected(self):
        with pytest.raises(ValidationError):
            ComicRequest(story_prompt="A story")

    def test_empty_strings_rejected(self):
        payload = dict(VALID, character_name="   ")
        with pytest.raises(ValidationError):
            ComicRequest(**payload)

    def test_prompt_too_short(self):
        with pytest.raises(ValidationError):
            ComicRequest(**dict(VALID, story_prompt="ab"))

    def test_prompt_too_long(self):
        with pytest.raises(ValidationError):
            ComicRequest(**dict(VALID, story_prompt="x" * 1001))

    def test_control_characters_stripped(self):
        request = ComicRequest(**dict(VALID, setting="Forest\x00 Land"))
        assert "\x00" not in request.setting
        assert request.setting == "Forest Land"

    def test_whitespace_collapsed(self):
        request = ComicRequest(**dict(VALID, tone="Very   Dramatic"))
        assert request.tone == "Very Dramatic"


class TestPanelModels:
    def test_panel_dialogue_text(self):
        from app.schemas import DialogueLine

        panel = Panel(
            panel_number=1,
            title="Intro",
            dialogue=[DialogueLine(speaker="Leo", line="Hello!"), DialogueLine(speaker="Sage", line="")],
        )
        assert panel.dialogue_text == "Leo: Hello!"

    def test_outline_requires_no_extra_fields(self):
        outline = ComicOutline.model_validate(
            {"comic_title": "T", "panels": [{"panel_number": 1, "title": "A"}]}
        )
        assert outline.panels[0].panel_number == 1

    def test_story_panel_number_bounds(self):
        from app.schemas import StoryPanel

        with pytest.raises(ValidationError):
            StoryPanel(panel_number=99)


class TestValidatorsAndHelpers:
    def test_valid_comic_id(self):
        assert valid_comic_id("abc123xyz9")
        assert not valid_comic_id("../etc")
        assert not valid_comic_id("")
        assert not valid_comic_id("UPPER")

    def test_valid_filename(self):
        assert valid_filename("comic_a1_b2.pdf")
        assert not valid_filename("../secrets.txt")
        assert not valid_filename("a/b.pdf")
        assert not valid_filename("")

    def test_sanitize_filename(self):
        assert sanitize_filename("C:\\evil\\name.png") == "name.png"
        assert sanitize_filename("comic-1_2.pdf") == "comic-1_2.pdf"
        with pytest.raises(ValueError):
            sanitize_filename("..")

    def test_safe_slug(self):
        assert safe_slug("Enchanted Forest!!") == "enchanted-forest"
        assert safe_slug("###") == "comic"

    def test_clean_text_max_length(self):
        assert len(clean_text("a" * 50, max_length=10)) == 10
