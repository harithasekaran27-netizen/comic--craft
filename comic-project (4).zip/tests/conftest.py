"""Test configuration.

All tests run fully offline: MOCK_AI=true makes the Gemini services return
deterministic mock content and the image provider degrades to the local
placeholder generator, so no paid API calls are ever made.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Must be configured BEFORE any app module is imported.
os.environ.setdefault("GEMINI_API_KEY", "test-key-not-real")
os.environ.setdefault("MOCK_AI", "true")
os.environ.setdefault("IMAGE_PROVIDER", "gemini")
os.environ.setdefault("PANEL_COUNT", "5")

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import BASE_DIR  # noqa: E402
from app.main import create_app  # noqa: E402

GENERATED_DIRS = [
    BASE_DIR / "static" / "panels",
    BASE_DIR / "static" / "exports",
    BASE_DIR / "data" / "comics",
]


@pytest.fixture(scope="session")
def client():
    with TestClient(create_app()) as test_client:
        yield test_client


@pytest.fixture(autouse=True, scope="session")
def _cleanup_generated_files():
    """Remove only the artifacts this test session created."""
    before = {
        directory: set(directory.glob("*")) if directory.exists() else set()
        for directory in GENERATED_DIRS
    }
    yield
    for directory, old_files in before.items():
        if not directory.exists():
            continue
        for path in directory.glob("*"):
            if path not in old_files and path.name != ".gitkeep":
                try:
                    path.unlink()
                except OSError:
                    pass


@pytest.fixture
def sample_request_payload() -> dict:
    return {
        "story_prompt": "A brave fox exploring an enchanted forest.",
        "character_name": "Leo",
        "setting": "Enchanted Forest",
        "tone": "Adventure",
        "art_style": "Comic Book",
    }
