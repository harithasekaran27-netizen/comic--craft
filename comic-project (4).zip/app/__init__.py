"""ComicCraft — AI Comic Story Creator."""

__version__ = "1.0.0"
