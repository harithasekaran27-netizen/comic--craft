"""Deterministic mock AI generators for development and testing.

NOT the real AI system: these produce clearly-labeled placeholder content so
the whole pipeline, UI and export flow can be exercised offline and in tests
without paid API calls. Real generation lives in gemini_flash.py / gemini_pro.py
and is used automatically as soon as a GEMINI_API_KEY is configured.
"""

from __future__ import annotations

from app.schemas import ComicOutline, ComicRequest, ComicStory, DialogueLine, OutlinePanel, StoryPanel

_BEATS = [
    ("Introduction", "{name} arrives at {setting}, ready for what lies ahead."),
    ("Development", "A path reveals itself, and {name} follows it deeper."),
    ("The Problem", "Something blocks the way — {name} must think fast."),
    ("Climax", "{name} takes the leap, heart pounding."),
    ("Resolution", "The {setting} quiets. {name} has changed."),
]


def mock_outline(request: ComicRequest, panel_count: int) -> ComicOutline:
    panels = [
        OutlinePanel(
            panel_number=i + 1,
            title=f"[Mock] {beat[0]}",
            scene_description=(
                f"[Mock outline] {beat[1].format(name=request.character_name, setting=request.setting)} "
                f"Tone: {request.tone}."
            ),
            image_prompt=(
                f"{request.character_name} in {request.setting}, {beat[0].lower()} moment, "
                f"{request.art_style.lower()} style, dramatic lighting, no text"
            ),
        )
        for i, beat in enumerate(_BEATS[:panel_count])
    ]
    return ComicOutline(
        comic_title=f"[Mock] {request.character_name} in the {request.setting}",
        character_description=(
            f"{request.character_name}, a character in a {request.art_style.lower()} "
            f"style with consistent colors and clothing in every panel"
        ),
        panels=panels,
    )


def mock_story(request: ComicRequest, outline: ComicOutline) -> ComicStory:
    panels = [
        StoryPanel(
            panel_number=p.panel_number,
            title=p.title,
            scene_description=p.scene_description,
            narration=(
                f"[Mock narration] Panel {p.panel_number}: {p.scene_description}"
            ),
            caption=f"{request.setting} — panel {p.panel_number}",
            dialogue=[
                DialogueLine(
                    speaker=request.character_name,
                    line=f"[Mock dialogue for panel {p.panel_number}.]",
                )
            ],
        )
        for p in outline.panels
    ]
    return ComicStory(comic_title=outline.comic_title, panels=panels)
