"""Stage orchestration — the complete generation pipeline (Phase 13).

    INPUT → VALIDATION → OUTLINE → STORY → IMAGE PROMPTS
          → IMAGE GENERATION → LAYOUT → (preview / export)

Failure policy: outline/story/layout failures stop the request gracefully with
a user-facing message; a single failed panel image marks that panel and the
rest of the comic continues.
"""

from __future__ import annotations

import logging
import time

from app.config import get_settings
from app.errors import ImageGenerationError
from app.schemas import Comic, ComicRequest, GenerationWarning, Panel
from app.services import gemini_flash, gemini_pro, layout_builder
from app.services.comic_store import save_comic
from app.services.image_generator import generate_image
from app.services.image_prompts import compose_image_prompt
from app.utils.helpers import new_comic_id, utc_now

logger = logging.getLogger("comiccraft.pipeline")


def generate_comic(request: ComicRequest) -> tuple[Comic, list[GenerationWarning]]:
    """Run the full pipeline; returns the comic plus non-fatal warnings."""
    settings = get_settings()
    started = time.monotonic()
    warnings: list[GenerationWarning] = []
    comic_id = new_comic_id()

    # 1) Outline (stops gracefully on failure — ComicServiceError propagates)
    logger.info("Pipeline start: %s", request.story_prompt[:60])
    outline = gemini_flash.generate_outline(request)

    # 2) Story + dialogue (same policy)
    story = gemini_pro.generate_story(request, outline)

    # 3+4) Image prompts + per-panel images; single failures mark the panel
    image_paths: dict[int, str | None] = {}
    image_errors: dict[int, str] = {}
    for panel in story.panels:
        prompt = compose_image_prompt(request, outline, panel)
        logger.info("Image generation started for panel %d", panel.panel_number)
        try:
            image_paths[panel.panel_number] = generate_image(
                prompt, comic_id=comic_id, panel_number=panel.panel_number
            )
        except ImageGenerationError as exc:
            logger.warning("Panel %d image failed: %s", panel.panel_number, exc.log_detail)
            image_paths[panel.panel_number] = None
            image_errors[panel.panel_number] = exc.user_message
            warnings.append(
                GenerationWarning(
                    stage="image",
                    message=(
                        f"Panel {panel.panel_number}: illustration could not be "
                        f"generated — the panel will show a placeholder instead."
                    ),
                )
            )

    # 5) Layout
    panels: list[Panel] = layout_builder.build_comic_layout(
        request, outline, story, image_paths, image_errors
    )

    comic = Comic(
        id=comic_id,
        title=story.comic_title or outline.comic_title,
        character_description=outline.character_description,
        created_at=utc_now(),
        request=request,
        panels=panels,
        mock_mode=settings.use_mock_ai,
    )
    save_comic(comic)

    elapsed = time.monotonic() - started
    logger.info(
        "Pipeline complete: comic %s (%d panels, %.1fs)", comic.id, len(comic.panels), elapsed
    )
    return comic, warnings
