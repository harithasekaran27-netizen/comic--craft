"""Stage 6 — PDF export (ReportLab).

``save_pdf()`` writes a professionally laid-out PDF of the complete comic into
``static/exports/`` and returns its URL path. Long text flows across pages,
missing images degrade gracefully, and image aspect ratios are preserved.
"""

from __future__ import annotations

import logging
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.config import BASE_DIR, EXPORTS_DIR
from app.errors import ExportError
from app.schemas import Comic
from app.utils.helpers import safe_slug, timestamp_slug

logger = logging.getLogger("comiccraft.export")

PAGE_W, PAGE_H = A4
MARGIN = 18 * mm
CONTENT_W = PAGE_W - 2 * MARGIN
MAX_IMAGE_H = 105 * mm

_INK = colors.HexColor("#241c3f")
_MUTED = colors.HexColor("#6d648c")
_ACCENT = colors.HexColor("#7c4dff")
_BOX_BG = colors.HexColor("#f3effc")

_FONT_CANDIDATES = [
    # (family, [regular, bold]) — first family that loads wins; drop DejaVu TTFs
    # into assets/fonts/ for full Unicode coverage on any OS.
    ("DejaVuSans", [
        str(BASE_DIR / "assets" / "fonts" / "DejaVuSans.ttf"),
        str(BASE_DIR / "assets" / "fonts" / "DejaVuSans-Bold.ttf"),
    ]),
    ("Arial", ["C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"]),
    ("DejaVuSans", [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ]),
]

_fonts_registered: dict[str, str] = {}


def _resolve_fonts() -> tuple[str, str]:
    """Pick Unicode-capable TTF fonts when available (Helvetica otherwise)."""
    global _fonts_registered
    if _fonts_registered:
        return _fonts_registered.get("regular", "Helvetica"), _fonts_registered.get(
            "bold", "Helvetica-Bold"
        )

    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    for name, candidates in _FONT_CANDIDATES:
        try:
            regular = candidates[0]
            bold = candidates[1] if len(candidates) > 1 else regular
            pdfmetrics.registerFont(TTFont(name, regular))
            pdfmetrics.registerFont(TTFont(f"{name}-Bold", bold))
            _fonts_registered = {"regular": name, "bold": f"{name}-Bold"}
            logger.info("PDF fonts: %s (regular+bold)", name)
            return name, f"{name}-Bold"
        except Exception:
            continue

    logger.info("PDF fonts: Helvetica built-ins (no Unicode TTF found)")
    _fonts_registered = {"regular": "Helvetica", "bold": "Helvetica-Bold"}
    return "Helvetica", "Helvetica-Bold"


def save_pdf(comic: Comic) -> str:
    """Render *comic* to a timestamped PDF; return its URL path."""
    regular, bold = _resolve_fonts()
    EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

    filename = f"comic_{comic.id}_{safe_slug(comic.title, 24)}_{timestamp_slug()}.pdf"
    pdf_path = EXPORTS_DIR / filename
    # Same-second collisions: append a counter until the filename is free.
    counter = 2
    while pdf_path.exists():
        pdf_path = EXPORTS_DIR / f"{filename.removesuffix('.pdf')}_{counter}.pdf"
        counter += 1

    styles = _build_styles(regular, bold)

    def _footer(canvas, doc):
        canvas.saveState()
        canvas.setFont(regular, 8)
        canvas.setFillColor(_MUTED)
        canvas.drawString(
            MARGIN, 10 * mm, f"ComicCraft — {comic.title} — page {doc.page}"
        )
        canvas.restoreState()

    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=A4,
        leftMargin=MARGIN,
        rightMargin=MARGIN,
        topMargin=MARGIN,
        bottomMargin=16 * mm,
        title=comic.title,
        author="ComicCraft",
    )

    story_flow: list = []

    # --- Cover block --------------------------------------------------------
    req = comic.request
    story_flow.append(Paragraph(comic.title, styles["cover"]))
    story_flow.append(Spacer(1, 4 * mm))
    meta = Table(
        [[f"Character: {req.character_name}   ·   Setting: {req.setting}"],
         [f"Tone: {req.tone}   ·   Art style: {req.art_style}"]],
        colWidths=[CONTENT_W],
    )
    meta.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _BOX_BG),
                ("TEXTCOLOR", (0, 0), (-1, -1), _MUTED),
                ("FONTNAME", (0, 0), (-1, -1), regular),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    story_flow.append(meta)
    story_flow.append(Spacer(1, 6 * mm))

    # --- Panels --------------------------------------------------------------
    for index, panel in enumerate(comic.panels):
        story_flow.append(
            Paragraph(f"Panel {panel.panel_number} — {panel.title}", styles["panel_h"])
        )
        story_flow.append(Spacer(1, 2 * mm))

        story_flow.extend(_image_flow(panel, styles, regular))
        story_flow.append(Spacer(1, 2 * mm))

        if panel.caption:
            story_flow.append(
                _boxed(Paragraph(panel.caption, styles["caption"]), CONTENT_W)
            )
            story_flow.append(Spacer(1, 2 * mm))
        if panel.scene_description:
            story_flow.append(
                Paragraph(f"<b>Scene.</b> {panel.scene_description}", styles["body"])
            )
            story_flow.append(Spacer(1, 1.5 * mm))
        if panel.narration:
            story_flow.append(
                Paragraph(f"<b>Narration.</b> {panel.narration}", styles["body"])
            )
            story_flow.append(Spacer(1, 1.5 * mm))
        if panel.dialogue:
            lines = "<br/>".join(
                f"<b>{_esc(d.speaker)}:</b> {_esc(d.line)}"
                for d in panel.dialogue
                if d.line
            )
            story_flow.append(_boxed(Paragraph(lines, styles["dialogue"]), CONTENT_W))

        if index < len(comic.panels) - 1:
            story_flow.append(PageBreak())

    try:
        doc.build(story_flow, onFirstPage=_footer, onLaterPages=_footer)
    except Exception as exc:
        if pdf_path.exists():
            pdf_path.unlink(missing_ok=True)
        raise ExportError(
            "The comic PDF could not be created. Please try again.",
            log_detail=f"ReportLab build failed: {type(exc).__name__}: {exc}",
        ) from exc

    url = f"/static/exports/{pdf_path.name}"
    logger.info("PDF exported: %s (%d panels)", url, len(comic.panels))
    return url


def _image_flow(panel, styles, regular_font: str):
    """Image flowable with aspect ratio preserved, or a graceful placeholder."""
    flow = []
    if panel.image_path:
        fs_path = BASE_DIR / "static" / panel.image_path.removeprefix("/static/")
        try:
            from PIL import Image as PILImage

            with PILImage.open(fs_path) as im:
                w, h = im.size
            draw_w = CONTENT_W
            draw_h = draw_w * h / w
            if draw_h > MAX_IMAGE_H:
                draw_h = MAX_IMAGE_H
                draw_w = draw_h * w / h
            flow.append(Image(str(fs_path), width=draw_w, height=draw_h))
            flow.append(Spacer(1, 2 * mm))
            return flow
        except Exception as exc:
            logger.warning(
                "Panel %d image unreadable (%s); exporting placeholder box",
                panel.panel_number,
                exc,
            )

    note = (
        "Image unavailable for this panel"
        + (f" ({panel.image_error})" if panel.image_error else "")
        + "."
    )
    box = Table([[note]], colWidths=[CONTENT_W], rowHeights=[40 * mm])
    box.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#efeaf7")),
                ("BOX", (0, 0), (-1, -1), 0.8, _MUTED),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("FONTNAME", (0, 0), (-1, -1), regular_font),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("TEXTCOLOR", (0, 0), (-1, -1), _MUTED),
            ]
        )
    )
    flow.append(box)
    flow.append(Spacer(1, 2 * mm))
    return flow


def _boxed(paragraph, width):
    box = Table([[paragraph]], colWidths=[width])
    box.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _BOX_BG),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#d8cffa")),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    return box


def _build_styles(regular: str, bold: str) -> dict[str, ParagraphStyle]:
    return {
        "cover": ParagraphStyle(
            "cover", fontName=bold, fontSize=24, leading=28, textColor=_INK
        ),
        "panel_h": ParagraphStyle(
            "panel_h", fontName=bold, fontSize=14, leading=18, textColor=_ACCENT
        ),
        "body": ParagraphStyle(
            "body", fontName=regular, fontSize=10, leading=14, textColor=_INK
        ),
        "caption": ParagraphStyle(
            "caption", fontName=regular, fontSize=9, leading=12, textColor=_MUTED
        ),
        "dialogue": ParagraphStyle(
            "dialogue", fontName=regular, fontSize=10, leading=14, textColor=_INK
        ),
    }


def _esc(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
