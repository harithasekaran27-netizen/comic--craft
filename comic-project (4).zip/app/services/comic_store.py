"""Comic storage: in-memory cache + JSON persistence in ``data/comics/``.

Comics survive dev-server reloads/restarts because every generated comic is
persisted to disk and reloaded on demand (needed for the PDF-export step).
"""

from __future__ import annotations

import json
import logging
from collections import OrderedDict

from app.config import COMICS_DATA_DIR, get_settings
from app.schemas import Comic
from app.utils.validators import valid_comic_id

logger = logging.getLogger("comiccraft.store")

_store: "OrderedDict[str, Comic]" = OrderedDict()


def save_comic(comic: Comic) -> None:
    """Store in memory (bounded) and persist to disk."""
    settings = get_settings()
    _store[comic.id] = comic
    while len(_store) > settings.max_stored_comics:
        evicted_id, _ = _store.popitem(last=False)
        logger.info("Evicted old comic %s from memory", evicted_id)

    COMICS_DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = COMICS_DATA_DIR / f"{comic.id}.json"
    path.write_text(comic.model_dump_json(), encoding="utf-8")


def get_comic(comic_id: str) -> Comic | None:
    """Load a comic from memory, falling back to the on-disk JSON copy."""
    if not valid_comic_id(comic_id):
        return None
    comic = _store.get(comic_id)
    if comic is not None:
        return comic

    path = COMICS_DATA_DIR / f"{comic_id}.json"
    if not path.exists():
        return None
    try:
        comic = Comic.model_validate(json.loads(path.read_text(encoding="utf-8")))
    except Exception as exc:
        logger.warning("Could not load persisted comic %s: %s", comic_id, exc)
        return None
    _store[comic_id] = comic
    return comic


def reset_store() -> None:
    """Clear the in-memory cache (used by tests)."""
    _store.clear()
