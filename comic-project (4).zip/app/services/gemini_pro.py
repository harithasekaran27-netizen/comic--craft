"""Stage 2 — detailed story, narration and dialogue generation (Gemini Pro).

``generate_story()`` takes the structured outline and writes every panel's
narration, dialogue and caption without changing the panel count or events.
"""

from __future__ import annotations

import json
import logging

from app.config import get_settings
from app.errors import AIGenerationError
from app.schemas import ComicOutline, ComicRequest, ComicStory
from app.services.gemini_client import generate_structured
from app.services.mock_ai import mock_story

logger = logging.getLogger("comiccraft.story")

_STORY_PROMPT = """\
You are a professional comic book scriptwriter.

Write the full script for a {panel_count}-panel comic based on this approved outline.

USER BRIEF
- Story prompt: {story_prompt}
- Main character: {character_name}
- Setting: {setting}
- Tone: {tone}
- Art style: {art_style}

APPROVED OUTLINE (JSON)
{outline_json}

For EVERY panel in the outline, keep the same panel numbers, titles, events and
order, and add:
- "scene_description": enriched 2-4 sentence scene detail
- "narration": 1-3 sentences of narrator text for this panel
- "caption": a short location/time caption (e.g. "Deep in the forest — dawn"),
  may be empty when not useful
- "dialogue": list of lines, each {{"speaker": name, "line": text}}; 1-3 lines,
  may be empty for silent panels

Rules:
- Return exactly {panel_count} panels with the same numbering as the outline.
- Keep {character_name}'s identity, appearance and personality consistent.
- No contradictions between panels; events must follow the outline.
- Dialogue must sound natural for the "{tone}" tone and fit in speech bubbles
  (max ~20 words per line).
- Write in English, suitable for a general audience.
"""


def generate_story(request: ComicRequest, outline: ComicOutline) -> ComicStory:
    """Generate and validate the full story script from the outline."""
    settings = get_settings()
    if settings.use_mock_ai:
        logger.info("Story generation: MOCK MODE (no Gemini call)")
        return mock_story(request, outline)

    logger.info("Story generation started (model=%s)", settings.gemini_story_model)
    prompt = _STORY_PROMPT.format(
        panel_count=settings.panel_count,
        story_prompt=request.story_prompt,
        character_name=request.character_name,
        setting=request.setting,
        tone=request.tone,
        art_style=request.art_style,
        outline_json=json.dumps(outline.model_dump(), indent=2),
    )

    story = generate_structured(
        model=settings.gemini_story_model,
        prompt=prompt,
        schema=ComicStory,
        stage="Story generation",
        temperature=0.8,
    )
    story = _reconcile_story(story, outline)
    logger.info("Story generation completed (%d panels)", len(story.panels))
    return story


def _reconcile_story(story: ComicStory, outline: ComicOutline) -> ComicStory:
    """Force the story to match the outline: count, order and titles."""
    if not story.panels:
        raise AIGenerationError(
            "The AI returned a story with no panels. Please try again.",
            log_detail="Story contained zero panels",
        )
    if len(story.panels) != len(outline.panels):
        raise AIGenerationError(
            "The AI returned an unexpected number of story panels. Please try again.",
            log_detail=(
                f"Story had {len(story.panels)} panels, "
                f"expected {len(outline.panels)}"
            ),
        )

    story.panels = sorted(story.panels, key=lambda p: p.panel_number)
    by_number = {p.panel_number: p for p in story.panels}
    for outline_panel in outline.panels:
        panel = by_number.get(outline_panel.panel_number)
        if panel is None:
            raise AIGenerationError(
                "The AI story was missing a panel. Please try again.",
                log_detail=f"Story missing panel {outline_panel.panel_number}",
            )
        panel.title = panel.title.strip() or outline_panel.title
        panel.panel_number = outline_panel.panel_number  # keep consistent numbering

    if not story.comic_title.strip():
        story.comic_title = outline.comic_title
    return story
