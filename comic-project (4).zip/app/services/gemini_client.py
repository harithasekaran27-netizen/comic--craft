"""Shared Gemini client + retry helper for all Gemini-backed services.

The current ``google-genai`` SDK is imported lazily so the application (and the
test suite) can run in placeholder/mock mode without the package installed.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Callable, Type, TypeVar

from pydantic import BaseModel, ValidationError

from app.config import get_settings
from app.errors import AIGenerationError

logger = logging.getLogger("comiccraft.gemini")

T = TypeVar("T", bound=BaseModel)

_client: Any = None


def get_client() -> Any:
    """Create (once) and return the google-genai client."""
    global _client
    if _client is None:
        from google import genai
        from google.genai import types

        settings = get_settings()
        _client = genai.Client(
            api_key=settings.gemini_api_key,
            http_options=types.HttpOptions(
                timeout=int(settings.request_timeout_seconds * 1000)
            ),
        )
    return _client


def reset_client() -> None:
    """Reset the cached client (used by tests)."""
    global _client
    _client = None


def generate_structured(
    model: str,
    prompt: str,
    schema: Type[T],
    *,
    stage: str,
    temperature: float = 0.8,
    system_instruction: str | None = None,
) -> T:
    """Call Gemini with a JSON response schema and return validated *schema*.

    Retries transient failures, then raises ``AIGenerationError`` with a safe
    user-facing message. Raw API errors are logged for developers only.
    """
    from google.genai import types

    settings = get_settings()
    attempts = max(1, settings.ai_max_retries + 1)
    last_error: Exception | None = None

    for attempt in range(1, attempts + 1):
        try:
            config = types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=schema,
                temperature=temperature,
            )
            if system_instruction:
                config.system_instruction = system_instruction

            response = get_client().models.generate_content(
                model=model,
                contents=prompt,
                config=config,
            )

            return _extract_schema(response, schema)

        except AIGenerationError as exc:
            # Malformed model output is worth one retry (LLM non-determinism).
            last_error = exc
        except ValidationError as exc:
            last_error = AIGenerationError(
                f"The AI returned an invalid {stage}. Please try again.",
                log_detail=f"{stage} schema validation failed: {exc}",
            )
        except Exception as exc:  # network / API / SDK errors
            last_error = AIGenerationError(
                "The AI story service could not be reached. Check your internet "
                "connection and API key, then try again.",
                log_detail=f"{stage} Gemini call failed ({type(exc).__name__}): {exc}",
            )

        if attempt < attempts:
            delay = 2.0 * attempt
            logger.warning(
                "%s attempt %d/%d failed (%s); retrying in %.0fs",
                stage,
                attempt,
                attempts,
                type(last_error).__name__,
                delay,
            )
            time.sleep(delay)

    assert last_error is not None
    logger.error("%s failed permanently: %s", stage, last_error.log_detail)
    raise last_error


def _extract_schema(response: Any, schema: Type[T]) -> T:
    """Prefer the SDK's parsed result, fall back to parsing ``response.text``."""
    parsed = getattr(response, "parsed", None)
    if isinstance(parsed, schema):
        return parsed

    text = (getattr(response, "text", None) or "").strip()
    if not text:
        raise AIGenerationError(
            "The AI returned an empty response. Please try again.",
            log_detail="Gemini returned empty text",
        )
    try:
        return schema.model_validate(json.loads(text))
    except (json.JSONDecodeError, ValidationError) as exc:
        raise AIGenerationError(
            "The AI returned unreadable output. Please try again.",
            log_detail=f"Could not parse Gemini JSON: {exc}; text={text[:400]!r}",
        ) from exc
