"""Stage 3 — image prompt composition (deterministic, no LLM call).

Each panel's final image prompt is derived from the actual story panel and the
outline's character sheet, guaranteeing character/setting/style consistency and
explicitly forbidding text inside the image.
"""

from __future__ import annotations

import logging

from app.schemas import ComicOutline, ComicRequest, StoryPanel

logger = logging.getLogger("comiccraft.image_prompts")

# Rotating camera framing so consecutive panels feel like a real comic page.
_FRAMINGS = (
    "wide establishing shot",
    "medium shot, character at three-quarter view",
    "close-up on the character's face and hands",
    "dynamic low-angle action shot",
    "wide shot, character small against the environment",
)

_LIGHTING = (
    "soft morning light",
    "warm afternoon light",
    "dramatic side lighting with strong shadows",
    "high-contrast cinematic lighting",
    "gentle golden-hour glow",
)


def compose_image_prompt(
    request: ComicRequest,
    outline: ComicOutline,
    panel: StoryPanel,
) -> str:
    """Build the final image-generation prompt for one panel."""
    index = (panel.panel_number - 1) % len(_FRAMINGS)
    framing = _FRAMINGS[index]
    lighting = _LIGHTING[index]

    parts: list[str] = [
        "Comic book panel illustration.",
        f"Character: {request.character_name}.",
    ]
    if outline.character_description:
        parts.append(f"Character appearance (keep identical in every panel): {outline.character_description}.")
    parts.append(f"Scene: {panel.scene_description or panel.title}.")
    if panel.narration:
        parts.append(f"Story context: {panel.narration}")
    parts.append(f"Setting: {request.setting}.")
    parts.append(f"Action/emotion: {panel.title}.")
    parts.append(f"Camera framing: {framing}.")
    parts.append(f"Lighting: {lighting}.")
    parts.append(f"Art style: {request.art_style}, consistent comic illustration style.")
    parts.append("Vibrant colors, clean composition, single cohesive scene.")
    parts.append("No text, no speech bubbles, no lettering, no watermarks in the image.")

    prompt = " ".join(part.strip() for part in parts if part and part.strip())
    logger.debug("Image prompt for panel %d: %s", panel.panel_number, prompt[:160])
    return prompt
