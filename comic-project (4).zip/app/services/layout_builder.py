"""Stage 5 — comic layout builder.

``build_comic_layout()`` merges the outline, story and generated images into one
clean structured list of panels where every image is guaranteed to belong to the
correct panel.
"""

from __future__ import annotations

import logging
from typing import Optional

from app.config import BASE_DIR
from app.errors import LayoutError
from app.schemas import ComicOutline, ComicRequest, ComicStory, Panel
from app.services.image_prompts import compose_image_prompt

logger = logging.getLogger("comiccraft.layout")


def build_comic_layout(
    request: ComicRequest,
    outline: ComicOutline,
    story: ComicStory,
    image_paths: dict[int, str | None],
    image_errors: Optional[dict[int, str]] = None,
) -> list[Panel]:
    """Combine outline + story + images into the final ordered panel list.

    ``image_paths`` maps panel_number -> URL path (or None when that panel's
    image failed). Raises ``LayoutError`` if the story/outline are inconsistent.
    """
    image_errors = image_errors or {}

    if len(story.panels) != len(outline.panels):
        raise LayoutError(
            "The comic layout could not be built consistently. Please try again.",
            log_detail=(
                f"Story has {len(story.panels)} panels but outline has "
                f"{len(outline.panels)}"
            ),
        )

    outline_by_number = {p.panel_number: p for p in outline.panels}
    panels: list[Panel] = []

    for story_panel in sorted(story.panels, key=lambda p: p.panel_number):
        outline_panel = outline_by_number.get(story_panel.panel_number)
        if outline_panel is None:
            raise LayoutError(
                "The comic layout could not be built consistently. Please try again.",
                log_detail=f"Story panel {story_panel.panel_number} missing from outline",
            )

        url = image_paths.get(story_panel.panel_number)
        if url and not (BASE_DIR / "static" / url.removeprefix("/static/")).exists():
            logger.warning(
                "Panel %d image missing on disk; marking as unavailable",
                story_panel.panel_number,
            )
            url = None

        panels.append(
            Panel(
                panel_number=story_panel.panel_number,
                title=story_panel.title or outline_panel.title,
                scene_description=(
                    story_panel.scene_description or outline_panel.scene_description
                ),
                narration=story_panel.narration,
                caption=story_panel.caption,
                dialogue=story_panel.dialogue,
                image_prompt=compose_image_prompt(request, outline, story_panel),
                image_path=url,
                image_error=image_errors.get(story_panel.panel_number) if not url else None,
            )
        )

    if not panels:
        raise LayoutError(
            "The comic layout could not be built. Please try again.",
            log_detail="Layout builder produced zero panels",
        )

    # Every image must correspond to the correct panel — verified by construction
    # (paths are keyed by panel_number) and re-checked here.
    for panel in panels:
        if panel.image_path:
            expected_prefix = f"/static/panels/"
            assert panel.image_path.startswith(expected_prefix), panel.image_path

    logger.info("Comic layout built: %d panels", len(panels))
    return panels
