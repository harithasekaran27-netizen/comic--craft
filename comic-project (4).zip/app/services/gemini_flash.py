"""Stage 1 — fast structured outline generation (Gemini Flash).

``generate_outline()`` turns the user's five inputs into a structured
5-panel outline with a character sheet used for visual consistency.
"""

from __future__ import annotations

import logging

from app.config import get_settings
from app.errors import AIGenerationError
from app.schemas import ComicOutline, ComicRequest
from app.services.gemini_client import generate_structured
from app.services.mock_ai import mock_outline

logger = logging.getLogger("comiccraft.outline")

_OUTLINE_PROMPT = """\
You are a professional comic book writer creating a tight {panel_count}-panel comic.

USER BRIEF
- Story prompt: {story_prompt}
- Main character: {character_name}
- Setting: {setting}
- Tone: {tone}
- Art style: {art_style}

Create a structured outline for a {panel_count}-panel comic with a clear, coherent
story progression. Suggested beats (adapt when the story needs it):
panel 1 introduction, panel 2 development, panel 3 conflict, panel 4 climax,
panel 5 resolution.

Rules:
- Exactly {panel_count} panels, numbered 1 to {panel_count}.
- Each panel: a short punchy title, a 2-3 sentence scene description, and a
  detailed image-generation prompt describing characters, action, framing,
  lighting and environment in the "{art_style}" art style.
- "character_description" is a consistent visual description of {character_name}
  (appearance, clothing, colours) that will be reused in every panel so the
  character looks the same throughout the comic.
- Image prompts must NOT ask for text, speech bubbles or lettering inside the image.
- Write in English. Keep everything suitable for a general audience.
"""


def generate_outline(request: ComicRequest) -> ComicOutline:
    """Generate and validate the structured comic outline.

    Uses mock mode (clearly labeled) when no API key is configured or when
    MOCK_AI=true, so local development and tests never need paid API calls.
    """
    settings = get_settings()
    if settings.use_mock_ai:
        logger.info("Outline generation: MOCK MODE (no Gemini call)")
        return mock_outline(request, settings.panel_count)

    logger.info("Outline generation started (model=%s)", settings.gemini_outline_model)
    prompt = _OUTLINE_PROMPT.format(
        panel_count=settings.panel_count,
        story_prompt=request.story_prompt,
        character_name=request.character_name,
        setting=request.setting,
        tone=request.tone,
        art_style=request.art_style,
    )

    outline = generate_structured(
        model=settings.gemini_outline_model,
        prompt=prompt,
        schema=ComicOutline,
        stage="Outline generation",
        temperature=0.9,
    )
    outline = _normalize_outline(outline, settings.panel_count)
    logger.info(
        "Outline generation completed: %r (%d panels)",
        outline.comic_title,
        len(outline.panels),
    )
    return outline


def _normalize_outline(outline: ComicOutline, expected_count: int) -> ComicOutline:
    """Validate panel count/order; never let the model change the panel count."""
    if not outline.panels:
        raise AIGenerationError(
            "The AI returned an outline with no panels. Please try again.",
            log_detail="Outline contained zero panels",
        )
    if len(outline.panels) != expected_count:
        raise AIGenerationError(
            "The AI returned an unexpected number of panels. Please try again.",
            log_detail=(
                f"Outline had {len(outline.panels)} panels, expected {expected_count}"
            ),
        )
    outline.panels = sorted(outline.panels, key=lambda p: p.panel_number)
    for index, panel in enumerate(outline.panels, start=1):
        panel.panel_number = index  # enforce consistent numbering
        panel.title = panel.title.strip() or f"Panel {index}"
        panel.scene_description = panel.scene_description.strip()
        panel.image_prompt = panel.image_prompt.strip()
    if not outline.comic_title.strip():
        outline.comic_title = "Untitled Comic"
    return outline
