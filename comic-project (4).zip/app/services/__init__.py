"""Service layer: one module per pipeline stage."""
