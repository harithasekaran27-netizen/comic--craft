"""Stage 4 — AI image generation with a pluggable provider layer.

``generate_image()`` saves a panel image into ``static/panels/`` and returns
its URL path. Providers (kept fully modular so the backend can be swapped via
configuration without touching the rest of the app):

- ``gemini``      — Gemini image model (default; no GPU required)
- ``hf``          — Hugging Face Inference API text-to-image (FLUX/SDXL)
- ``placeholder`` — clearly-labeled local Pillow placeholder (tests/mock mode)
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable

from app.config import EXPORTS_DIR, PANELS_DIR, get_settings
from app.errors import ImageGenerationError
from app.utils.helpers import new_comic_id, safe_slug

logger = logging.getLogger("comiccraft.imagegen")

PANELS_URL = "/static/panels"


def generate_image(prompt: str, *, comic_id: str | None = None, panel_number: int = 0) -> str:
    """Generate one panel image and return its URL path under /static/panels.

    Raises ``ImageGenerationError`` on failure; callers decide whether to mark a
    single panel or abort the request.
    """
    settings = get_settings()
    provider = settings.effective_image_provider

    comic_id = comic_id or new_comic_id()
    slug = safe_slug(prompt, max_length=24, fallback="panel")
    suffix = f"_{panel_number}" if panel_number else ""
    filename = f"{comic_id}{suffix}_{slug}.png"
    filepath = PANELS_DIR / filename

    generators: dict[str, Callable[[str, Path, float], None]] = {
        "gemini": _generate_with_gemini,
        "hf": _generate_with_hf,
        "placeholder": _generate_placeholder,
    }
    try:
        generators[provider](prompt, filepath, settings.image_timeout_seconds)
    except ImageGenerationError:
        raise
    except Exception as exc:  # provider bugs, disk errors, unexpected formats
        raise ImageGenerationError(
            "Image generation failed for one panel.",
            log_detail=f"{provider} provider error for {filename}: {type(exc).__name__}: {exc}",
        ) from exc

    url = f"{PANELS_URL}/{filename}"
    logger.info("Image generated via %s: %s", provider, url)
    return url


# --------------------------------------------------------------------------- #
# Provider: Gemini image model
# --------------------------------------------------------------------------- #


def _generate_with_gemini(prompt: str, filepath: Path, timeout: float) -> None:
    from google.genai import types

    from app.services.gemini_client import get_client

    client = get_client()
    response = client.models.generate_content(
        model=get_settings().gemini_image_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_modalities=["IMAGE"],
        ),
    )
    image_bytes = _extract_image_bytes(response)
    if not image_bytes:
        raise ImageGenerationError(
            "The image model returned no image for a panel.",
            log_detail=f"Gemini image response had no inline image data: {response}",
        )
    _save_png(image_bytes, filepath)


def _extract_image_bytes(response: object) -> bytes | None:
    candidates = getattr(response, "candidates", None) or []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        for part in getattr(content, "parts", None) or []:
            inline = getattr(part, "inline_data", None)
            if inline and getattr(inline, "data", None):
                return inline.data
    return None


# --------------------------------------------------------------------------- #
# Provider: Hugging Face Inference API
# --------------------------------------------------------------------------- #


def _generate_with_hf(prompt: str, filepath: Path, timeout: float) -> None:
    import httpx

    settings = get_settings()
    url = f"https://router.huggingface.co/hf-inference/models/{settings.hf_image_model}"
    headers = {"Authorization": f"Bearer {settings.hf_api_key}"}
    payload = {"inputs": prompt, "parameters": {"guidance_scale": 7.5}}

    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.post(url, headers=headers, json=payload)
    except httpx.HTTPError as exc:
        raise ImageGenerationError(
            "Could not reach the Hugging Face image service.",
            log_detail=f"HF request failed: {exc}",
        ) from exc

    if response.status_code != 200:
        raise ImageGenerationError(
            "The Hugging Face image service rejected the request.",
            log_detail=(
                f"HF HTTP {response.status_code}: {response.text[:300]}"
            ),
        )
    content_type = response.headers.get("content-type", "")
    if "image" not in content_type:
        raise ImageGenerationError(
            "The Hugging Face image service returned an unexpected response.",
            log_detail=f"HF returned content-type {content_type}: {response.text[:300]}",
        )
    _save_png(response.content, filepath)


# --------------------------------------------------------------------------- #
# Provider: local placeholder (tests / mock mode only)
# --------------------------------------------------------------------------- #


def _generate_placeholder(prompt: str, filepath: Path, timeout: float) -> None:
    """Draw a clearly-labeled placeholder panel with Pillow (NOT real AI art)."""
    from io import BytesIO

    from PIL import Image, ImageDraw, ImageFont

    width, height = 1024, 768
    image = Image.new("RGB", (width, height), "#2b2350")
    draw = ImageDraw.Draw(image)

    draw.rectangle((16, 16, width - 16, height - 16), outline="#ffd166", width=6)
    draw.rectangle((16, 16, width - 16, 140), fill="#1b1638")

    def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
        for candidate in (
            "C:/Windows/Fonts/segoeuib.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
            "C:/Windows/Fonts/arial.ttf",
        ):
            try:
                return ImageFont.truetype(candidate, size)
            except OSError:
                continue
        return ImageFont.load_default()

    draw.text((40, 45), "PLACEHOLDER IMAGE (mock mode)", fill="#ffd166", font=_font(44))

    words = prompt.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) > 60:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)

    y = 200
    for line in lines[:12]:
        draw.text((40, y), line, fill="#e8e1ff", font=_font(26))
        y += 40

    draw.text(
        (40, height - 70),
        "Add GEMINI_API_KEY to .env for real AI illustrations.",
        fill="#9d94c7",
        font=_font(22),
    )

    buffer = BytesIO()
    image.save(buffer, format="PNG")
    _save_png(buffer.getvalue(), filepath)


# --------------------------------------------------------------------------- #
# Shared save helper
# --------------------------------------------------------------------------- #


def _save_png(data: bytes, filepath: Path) -> None:
    """Validate that *data* really is an image, then atomically write it."""
    from io import BytesIO

    from PIL import Image, UnidentifiedImageError

    try:
        with Image.open(BytesIO(data)) as im:
            im.verify()
    except (UnidentifiedImageError, Exception) as exc:
        raise ImageGenerationError(
            "The image provider returned invalid image data.",
            log_detail=f"Image bytes failed validation: {exc}",
        ) from exc

    filepath.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = filepath.with_suffix(".tmp")
    tmp_path.write_bytes(data)
    tmp_path.replace(filepath)
