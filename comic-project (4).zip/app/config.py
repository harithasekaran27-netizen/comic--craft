"""Centralized configuration for ComicCraft.

All settings come from environment variables (optionally via a ``.env`` file).
Secrets are never exposed to templates or API responses.
"""

from __future__ import annotations

import logging
from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger("comiccraft.config")

BASE_DIR = Path(__file__).resolve().parent.parent
PANELS_DIR = BASE_DIR / "static" / "panels"
EXPORTS_DIR = BASE_DIR / "static" / "exports"
COMICS_DATA_DIR = BASE_DIR / "data" / "comics"

VALID_IMAGE_PROVIDERS = ("gemini", "hf", "placeholder")


class Settings(BaseSettings):
    """Application settings loaded from the environment / .env file."""

    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- secrets -----------------------------------------------------------
    gemini_api_key: str = Field(default="", repr=False)
    hf_api_key: str = Field(default="", repr=False)

    # --- behaviour ---------------------------------------------------------
    mock_ai: bool = False
    image_provider: str = "gemini"
    panel_count: int = 5

    # --- models (centralized so they can be swapped without code changes) ---
    gemini_outline_model: str = "gemini-3.8-flash"
    gemini_story_model: str = "gemini-3.8-flash"
    gemini_image_model: str = "gemini-3.1-flash-image"
    hf_image_model: str = "stabilityai/stable-diffusion-3-medium-diffusers"

    # --- limits / timeouts (seconds) ----------------------------------------
    request_timeout_seconds: float = 120.0
    image_timeout_seconds: float = 180.0
    ai_max_retries: int = 2
    max_stored_comics: int = 50

    # --- derived state -------------------------------------------------------
    @property
    def gemini_configured(self) -> bool:
        return bool(self.gemini_api_key.strip())

    @property
    def hf_configured(self) -> bool:
        return bool(self.hf_api_key.strip())

    @property
    def use_mock_ai(self) -> bool:
        """Mock mode is explicit via MOCK_AI, or forced when no Gemini key exists."""
        return self.mock_ai or not self.gemini_configured

    @property
    def effective_image_provider(self) -> str:
        """Resolve the image provider, degrading safely when credentials are absent."""
        provider = self.image_provider.strip().lower()
        if provider not in VALID_IMAGE_PROVIDERS:
            logger.warning(
                "Unknown IMAGE_PROVIDER %r; falling back to 'placeholder'.", provider
            )
            return "placeholder"
        if provider == "gemini" and self.use_mock_ai:
            return "placeholder"
        if provider == "hf" and not self.hf_configured:
            logger.warning(
                "IMAGE_PROVIDER=hf but HF_API_KEY is not set; falling back to 'placeholder'."
            )
            return "placeholder"
        return provider

    def validate_runtime(self) -> list[str]:
        """Validate configuration at startup.

        Returns a list of human-readable warnings. Raises RuntimeError only when
        the user explicitly disabled mock mode without providing credentials.
        """
        warnings: list[str] = []

        if not self.gemini_configured:
            if self.mock_ai:
                raise RuntimeError(
                    "MOCK_AI=true but GEMINI_API_KEY is set to empty and mock mode was "
                    "explicitly requested. Set GEMINI_API_KEY in .env "
                    "(see .env.example) or remove MOCK_AI to auto-fallback."
                )
            warnings.append(
                "GEMINI_API_KEY is not configured - running in MOCK mode: stories are "
                "deterministic placeholders, images are placeholder graphics. "
                "Add your key to .env to enable real Gemini generation."
            )

        if self.image_provider == "hf" and not self.hf_configured:
            warnings.append(
                "IMAGE_PROVIDER=hf but HF_API_KEY is missing - image generation will "
                "use placeholder graphics."
            )

        if self.panel_count < 1 or self.panel_count > 12:
            warnings.append(
                f"PANEL_COUNT={self.panel_count} outside 1-12; clamping to 5."
            )
            self.panel_count = 5

        return warnings


@lru_cache
def get_settings() -> Settings:
    """Cached settings accessor (override in tests by clearing the cache)."""
    return Settings()
