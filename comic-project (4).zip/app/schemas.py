"""Pydantic models: request validation, AI output schemas, and domain models.

Structured JSON is used everywhere (Gemini ``response_schema``) so the app never
depends on fragile parsing of raw AI prose.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.utils.validators import clean_text

# --------------------------------------------------------------------------- #
# User request
# --------------------------------------------------------------------------- #


class ComicRequest(BaseModel):
    """The five inputs that drive the whole comic pipeline."""

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "story_prompt": "A brave fox exploring an enchanted forest.",
                "character_name": "Leo",
                "setting": "Enchanted Forest",
                "tone": "Adventure",
                "art_style": "Comic Book",
            }
        }
    )

    story_prompt: str = Field(
        ...,
        min_length=3,
        max_length=1000,
        description="What the comic should be about.",
        examples=["A brave fox exploring an enchanted forest."],
    )
    character_name: str = Field(
        ..., min_length=1, max_length=60, description="Name of the main character."
    )
    setting: str = Field(
        ...,
        min_length=2,
        max_length=120,
        description="Where the story takes place (Forest, School, City, Space...).",
        examples=["Enchanted Forest"],
    )
    tone: str = Field(
        ...,
        min_length=2,
        max_length=60,
        description="Story tone (Light-hearted, Dramatic, Poetic, Funny...).",
        examples=["Adventure"],
    )
    art_style: str = Field(
        ...,
        min_length=2,
        max_length=60,
        description="Visual art style (Anime, Pixel Art, Comic Book, Realistic...).",
        examples=["Comic Book"],
    )

    @field_validator("story_prompt", "character_name", "setting", "tone", "art_style")
    @classmethod
    def _normalize(cls, value: str) -> str:
        value = clean_text(value)
        if not value:
            raise ValueError("must not be empty or only whitespace")
        return value


# --------------------------------------------------------------------------- #
# AI output schemas (also used as Gemini response_schema)
# --------------------------------------------------------------------------- #


class OutlinePanel(BaseModel):
    """One panel of the structured outline produced by the fast model."""

    panel_number: int = Field(..., ge=1, le=12)
    title: str = ""
    scene_description: str = ""
    image_prompt: str = ""


class ComicOutline(BaseModel):
    """Structured 5-panel outline plus a character sheet for visual consistency."""

    comic_title: str = "Untitled Comic"
    character_description: str = ""
    panels: List[OutlinePanel] = Field(default_factory=list)


class DialogueLine(BaseModel):
    speaker: str = "Narrator"
    line: str = ""


class StoryPanel(BaseModel):
    """One panel enriched with narration, dialogue and caption by the story model."""

    panel_number: int = Field(..., ge=1, le=12)
    title: str = ""
    scene_description: str = ""
    narration: str = ""
    caption: str = ""
    dialogue: List[DialogueLine] = Field(default_factory=list)


class ComicStory(BaseModel):
    """Full story: same panel count/order as the outline, now fully written."""

    comic_title: str = "Untitled Comic"
    panels: List[StoryPanel] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# Domain models
# --------------------------------------------------------------------------- #


class Panel(BaseModel):
    """A fully generated comic panel as used by layout, preview and PDF."""

    panel_number: int
    title: str = ""
    scene_description: str = ""
    narration: str = ""
    caption: str = ""
    dialogue: List[DialogueLine] = Field(default_factory=list)
    image_prompt: str = ""
    image_path: Optional[str] = None  # URL path under /static, None if image failed
    image_error: Optional[str] = None  # safe message when the image failed

    @property
    def dialogue_text(self) -> str:
        return "\n".join(f"{d.speaker}: {d.line}" for d in self.dialogue if d.line)


class Comic(BaseModel):
    """Complete generated comic, persisted to data/comics/<id>.json."""

    id: str
    title: str = "Untitled Comic"
    character_description: str = ""
    created_at: datetime
    request: ComicRequest
    panels: List[Panel] = Field(default_factory=list)
    mock_mode: bool = False


# --------------------------------------------------------------------------- #
# API responses
# --------------------------------------------------------------------------- #


class GenerationWarning(BaseModel):
    stage: str
    message: str


class GenerationResponse(BaseModel):
    """Response of POST /generate-comic/json."""

    comic_id: str
    title: str
    mock_mode: bool
    panels: List[Panel]
    warnings: List[GenerationWarning] = Field(default_factory=list)
    export_url: str = "/export"
    preview_url: str


class ExportResponse(BaseModel):
    """Response describing a generated PDF export."""

    success: bool
    comic_id: str
    pdf_url: str = ""
    filename: str = ""
    message: str = ""


class TestImageRequest(BaseModel):
    prompt: str = Field(
        ...,
        min_length=3,
        max_length=1000,
        examples=["A brave fox standing in an enchanted forest, comic book illustration."],
    )


class TestImageResponse(BaseModel):
    success: bool
    provider: str
    image_url: str = ""
    filename: str = ""
    message: str = ""


class ErrorResponse(BaseModel):
    detail: str
