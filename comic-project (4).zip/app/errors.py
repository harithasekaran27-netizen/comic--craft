"""Application error types with safe, user-facing messages.

Every service failure raises one of these. ``user_message`` is safe to show to
end users; details go to the developer log only.
"""

from __future__ import annotations


class ComicServiceError(Exception):
    """Base class for all ComicCraft service errors."""

    def __init__(self, user_message: str, log_detail: str | None = None) -> None:
        super().__init__(user_message)
        self.user_message = user_message
        self.log_detail = log_detail or user_message


class ConfigurationError(ComicServiceError):
    """Raised when required configuration is missing or invalid."""


class AIGenerationError(ComicServiceError):
    """Raised when an AI (Gemini) call fails permanently or returns unusable output."""


class ImageGenerationError(ComicServiceError):
    """Raised when generating or saving a panel image fails."""


class LayoutError(ComicServiceError):
    """Raised when building the comic layout fails."""


class ExportError(ComicServiceError):
    """Raised when PDF export fails."""
