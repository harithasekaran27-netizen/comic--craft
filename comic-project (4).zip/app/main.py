"""ComicCraft FastAPI application factory.

Run with:  uvicorn app.main:app --reload
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.templating import Jinja2Templates

from app import __version__
from app.config import BASE_DIR, COMICS_DATA_DIR, EXPORTS_DIR, PANELS_DIR, get_settings
from app.errors import ComicServiceError
from app.routes import router

logger = logging.getLogger("comiccraft.app")

_FORMAT = "%(asctime)s %(levelname)-7s %(name)s | %(message)s"


def _configure_logging() -> None:
    root = logging.getLogger("comiccraft")
    if not root.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(_FORMAT))
        root.addHandler(handler)
        root.setLevel(logging.INFO)
    logging.getLogger("uvicorn").setLevel(logging.INFO)


def _wants_json(request: Request) -> bool:
    """Decide between an HTML error page and a JSON error body."""
    if request.url.path.startswith(("/generate-comic", "/test-image", "/health")):
        return True
    accept = request.headers.get("accept", "")
    return "application/json" in accept and "text/html" not in accept


def create_app() -> FastAPI:
    _configure_logging()

    @asynccontextmanager
    async def _lifespan(app: FastAPI):
        for directory in (PANELS_DIR, EXPORTS_DIR, COMICS_DATA_DIR):
            directory.mkdir(parents=True, exist_ok=True)
        settings = get_settings()
        logger.info("ComicCraft %s starting", __version__)
        logger.info(
            "Image provider: %s | mock AI: %s | outline: %s | story: %s | image model: %s",
            settings.effective_image_provider,
            settings.use_mock_ai,
            settings.gemini_outline_model,
            settings.gemini_story_model,
            settings.gemini_image_model,
        )
        for warning in settings.validate_runtime():
            logger.warning("CONFIG WARNING: %s", warning)
        yield

    app = FastAPI(
        title="ComicCraft — AI Comic Story Creator",
        description=(
            "Turn a story prompt, character, setting, tone and art style into a "
            "5-panel AI comic with illustrations and PDF export.\n\n"
            "**Pipeline:** outline (Gemini Flash) → story & dialogue (Gemini Pro) "
            "→ image prompts → AI illustrations → layout → preview → PDF."
        ),
        version=__version__,
        lifespan=_lifespan,
    )
    templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
    app.state.templates = templates

    # ------------------------- exception handlers ------------------------- #

    def _error_response(request: Request, status: int, message: str, hint: str = ""):
        if _wants_json(request):
            return JSONResponse(status_code=status, content={"detail": message})
        return templates.TemplateResponse(
            request,
            "error.html",
            {"message": message, "hint": hint},
            status_code=status,
        )

    @app.exception_handler(ComicServiceError)
    async def _comic_service_error(request: Request, exc: ComicServiceError):
        logger.error("Service error: %s", exc.log_detail)
        return _error_response(
            request,
            502,
            exc.user_message,
            "Your story inputs were kept — press Back and try again.",
        )

    @app.exception_handler(RequestValidationError)
    async def _validation_error(request: Request, exc: RequestValidationError):
        problems = []
        for item in exc.errors():
            field = ".".join(str(part) for part in item.get("loc", ()) if part != "body")
            problems.append(f"{field or 'input'}: {item.get('msg', 'invalid value')}")
        message = "Please fix the highlighted fields: " + "; ".join(problems[:5])
        if _wants_json(request):
            return JSONResponse(status_code=422, content={"detail": message})
        return templates.TemplateResponse(
            request,
            "index.html",
            {"errors": problems, "form": {}, "mock_mode": get_settings().use_mock_ai},
            status_code=422,
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http_error(request: Request, exc: StarletteHTTPException):
        message = {
            404: "The page you are looking for does not exist.",
            405: "That action is not allowed on this page.",
        }.get(exc.status_code, "Something went wrong handling your request.")
        return _error_response(request, exc.status_code, message)

    @app.exception_handler(Exception)
    async def _unhandled_error(request: Request, exc: Exception):
        logger.exception("Unhandled server error: %s", type(exc).__name__)
        return _error_response(
            request,
            500,
            "An unexpected error occurred while creating your comic.",
            "The issue has been logged. Please try again.",
        )

    # ------------------------- routes & static ---------------------------- #
    app.include_router(router)
    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

    return app


app = create_app()
