"""All HTTP routes: HTML pages, the JSON API, export and the image test route."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import RedirectResponse
from pydantic import ValidationError

from app.config import EXPORTS_DIR, get_settings
from app.errors import ComicServiceError
from app.schemas import (
    ComicRequest,
    ExportResponse,
    GenerationResponse,
    TestImageRequest,
    TestImageResponse,
)
from app.services import comic_pipeline
from app.services.comic_store import get_comic
from app.services.exporters import save_pdf
from app.services.image_generator import generate_image
from app.utils.validators import valid_comic_id, valid_filename

logger = logging.getLogger("comiccraft.routes")

router = APIRouter()

_FORM_FIELDS = ("story_prompt", "character_name", "setting", "tone", "art_style")


@router.get("/", include_in_schema=False)
async def home(request: Request):
    """Render the comic creator home page."""
    return request.app.state.templates.TemplateResponse(
        request,
        "index.html",
        {"form": {}, "errors": [], "mock_mode": get_settings().use_mock_ai},
    )


@router.post("/generate", include_in_schema=False)
async def generate_comic_page(request: Request):
    """HTML form flow: validate → pipeline → render the comic preview page."""
    templates = request.app.state.templates
    form = await request.form()
    raw = {field: str(form.get(field, "")) for field in _FORM_FIELDS}

    try:
        comic_request = ComicRequest(**raw)
    except ValidationError as exc:
        errors = [
            f"{' '.join(str(part) for part in e['loc'])}: {e['msg']}"
            for e in exc.errors()
        ]
        return templates.TemplateResponse(
            request,
            "index.html",
            {"form": raw, "errors": errors, "mock_mode": get_settings().use_mock_ai},
            status_code=422,
        )

    comic, warnings = await run_in_threadpool(comic_pipeline.generate_comic, comic_request)
    return templates.TemplateResponse(
        request,
        "comic_preview.html",
        {"comic": comic, "warnings": warnings},
    )


@router.post(
    "/generate-comic/json",
    response_model=GenerationResponse,
    summary="Generate a complete comic (JSON API)",
    description=(
        "Runs the full pipeline — outline, story, image prompts, illustrations "
        "and layout — and returns the structured comic. Panel images that fail "
        "are returned with `image_path: null` plus a warning instead of failing "
        "the whole request."
    ),
    responses={502: {"description": "AI service failure"}, 422: {"description": "Invalid input"}},
)
async def generate_comic_json(payload: ComicRequest) -> GenerationResponse:
    """JSON API equivalent of POST /generate."""
    comic, warnings = await run_in_threadpool(comic_pipeline.generate_comic, payload)
    return GenerationResponse(
        comic_id=comic.id,
        title=comic.title,
        mock_mode=comic.mock_mode,
        panels=comic.panels,
        warnings=warnings,
        export_url="/export",
        preview_url=f"/comic/{comic.id}",
    )


@router.get("/comic/{comic_id}", include_in_schema=False)
async def comic_preview_page(request: Request, comic_id: str):
    """Re-open a generated comic's preview page by id."""
    if not valid_comic_id(comic_id):
        raise HTTPException(status_code=404, detail="Comic not found")
    comic = get_comic(comic_id)
    if comic is None:
        raise HTTPException(status_code=404, detail="Comic not found")
    return request.app.state.templates.TemplateResponse(
        request, "comic_preview.html", {"comic": comic, "warnings": []}
    )


@router.post(
    "/export",
    response_model=None,
    include_in_schema=False,
    summary="Export a comic to PDF",
)
async def export_comic(comic_id: str = Form(...)):
    """Generate the PDF for a stored comic, then redirect to the success page."""
    if not valid_comic_id(comic_id):
        raise HTTPException(status_code=404, detail="Comic not found")
    comic = get_comic(comic_id)
    if comic is None:
        raise HTTPException(
            status_code=404, detail="Comic not found — it may have expired."
        )

    pdf_url = await run_in_threadpool(save_pdf, comic)
    filename = pdf_url.rsplit("/", 1)[-1]
    return RedirectResponse(
        url=f"/export-success?pdf={filename}&comic_id={comic_id}", status_code=303
    )


@router.get(
    "/export-success",
    include_in_schema=False,
    summary="Export success page",
)
async def export_success(request: Request, pdf: str = "", comic_id: str = ""):
    """Render the export success page with the download link."""
    download_url = ""
    if pdf:
        if not valid_filename(pdf) or not (EXPORTS_DIR / pdf).exists():
            logger.warning("export-success requested unknown pdf %r", pdf)
            raise HTTPException(status_code=404, detail="Export file not found")
        download_url = f"/static/exports/{pdf}"
    return request.app.state.templates.TemplateResponse(
        request,
        "export_success.html",
        {"download_url": download_url, "filename": pdf, "comic_id": comic_id},
    )


@router.get("/test-image", include_in_schema=False)
async def test_image_page(request: Request):
    """Developer page to try the image pipeline with a single prompt."""
    return request.app.state.templates.TemplateResponse(
        request,
        "test_image.html",
        {"provider": get_settings().effective_image_provider,
         "mock_mode": get_settings().use_mock_ai},
    )


@router.post(
    "/test-image",
    response_model=TestImageResponse,
    summary="Test image generation with one prompt",
    description=(
        "Developer/testing endpoint: generates a single image with the currently "
        "configured provider and returns its URL. In mock mode (no API key) it "
        "returns a clearly-labeled placeholder graphic."
    ),
    responses={422: {"description": "Invalid prompt"}, 502: {"description": "Image provider failure"}},
)
async def test_image(request: Request) -> TestImageResponse:
    content_type = request.headers.get("content-type", "")

    if content_type.startswith("application/json"):
        payload = await request.json()
        try:
            body = TestImageRequest(**payload)
        except ValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors()[0]["msg"]) from exc
    else:
        form = await request.form()
        try:
            body = TestImageRequest(prompt=str(form.get("prompt", "")))
        except ValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors()[0]["msg"]) from exc

    settings = get_settings()
    try:
        image_url = await run_in_threadpool(generate_image, body.prompt)
    except ComicServiceError as exc:
        logger.error("test-image failed: %s", exc.log_detail)
        raise HTTPException(status_code=502, detail=exc.user_message) from exc

    return TestImageResponse(
        success=True,
        provider=settings.effective_image_provider,
        image_url=image_url,
        filename=image_url.rsplit("/", 1)[-1],
        message=(
            "Placeholder image generated (mock mode)."
            if settings.effective_image_provider == "placeholder"
            else "Image generated successfully."
        ),
    )


@router.get("/health", include_in_schema=False)
async def health():
    settings = get_settings()
    return {
        "status": "ok",
        "mock_ai": settings.use_mock_ai,
        "image_provider": settings.effective_image_provider,
    }
