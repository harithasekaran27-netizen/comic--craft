"""Small shared helpers: ids, slugs, timestamps, file names."""

from __future__ import annotations

import re
import secrets
import string
from datetime import datetime, timezone

_ALPHANUM = string.ascii_lowercase + string.digits


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def new_comic_id() -> str:
    """Short, URL-safe, filesystem-safe comic identifier (e.g. ``k7f3aq2m``)."""
    return "".join(secrets.choice(_ALPHANUM) for _ in range(10))


def timestamp_slug() -> str:
    """Filesystem-safe UTC timestamp like ``20260927-153045``."""
    return utc_now().strftime("%Y%m%d-%H%M%S")


def safe_slug(text: str, max_length: int = 40, fallback: str = "comic") -> str:
    """Turn arbitrary text into a safe filename slug.

    Strips everything except ``a-z0-9-`` and collapses separators so the result
    can never contain path traversal characters.
    """
    slug = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    slug = slug[:max_length].strip("-")
    return slug or fallback


def sanitize_filename(name: str) -> str:
    """Return a basename-only, safe filename; raises on empty input."""
    basename = (name or "").replace("\\", "/").rsplit("/", 1)[-1]
    basename = basename.strip().replace(" ", "_")
    if not basename or basename in {".", ".."} or re.search(r"[^A-Za-z0-9._-]", basename):
        raise ValueError(f"Unsafe or empty filename: {name!r}")
    return basename
