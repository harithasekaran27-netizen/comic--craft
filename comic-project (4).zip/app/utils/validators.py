"""Input validation helpers shared by Pydantic models and routes."""

from __future__ import annotations

import re

# Text that may legitimately contain punctuation but no control characters.
_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

COMIC_ID_PATTERN = re.compile(r"^[a-z0-9]{6,24}$")

DANGEROUS_FILENAME = re.compile(r"[\\/:*?\"<>|\x00-\x1f]")


def clean_text(value: str | None, *, max_length: int | None = None) -> str:
    """Normalize free text: strip, collapse inner whitespace, drop control chars."""
    if value is None:
        return ""
    cleaned = _CONTROL_CHARS.sub("", value)
    cleaned = " ".join(cleaned.split())
    if max_length is not None:
        cleaned = cleaned[:max_length].rstrip()
    return cleaned


def valid_comic_id(comic_id: str) -> bool:
    """True when *comic_id* matches the safe generated-id format."""
    return bool(COMIC_ID_PATTERN.match(comic_id or ""))


def valid_filename(filename: str) -> bool:
    """True when *filename* is a safe basename (no paths, no weird characters)."""
    if not filename or filename in {".", ".."}:
        return False
    if "/" in filename or "\\" in filename:
        return False
    return not DANGEROUS_FILENAME.search(filename)
