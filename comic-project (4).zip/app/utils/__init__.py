"""Shared utilities."""
